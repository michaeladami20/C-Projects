/* --------------------------------------------------------
 * prog2RallySongs.cpp
 *    Read political candidate's favorite song lyrics from a file.
 *    Choose random lines and see if the reader can identify the candidate.
 *
 *    This was inspired by the New York Times article:
 *       https://www.nytimes.com/interactive/2019/08/19/us/politics/presidential-campaign-songs-playlists.html
 *    which describes the different songs played at political rallies for
 *    different 2020 presidential candidates.
 *
 * Class: Program #2 for CS 141, Fall 2019
 * Lab: Tuesday 2pm,
 * TA Seo Yeon Park
 * System: Windows 10
 * Author: Michael J Adami III
 */

#include <iostream>
#include <cctype>       // For the letter checking functions
#include <fstream>      // For file input
#include <iomanip>      // For setw
#include <cstdlib>      // For exit and abs
using namespace std;

/* DisplayTheLyrics function: Its displays lyrics to choice 2,3, and the quiz.
 * If you enter into the program:
 * It will output:
 *1. default of 3 lyrics or how many the user wants to see.
 *2. It gets called from 2,3, and the quiz.
 *3. It receives the candidate name and the lines inputed or the default from main of 3.
 *4. It compares a random int variable(lining) and compares it to a counter. For all the lines ran. */

void DisplayTheLyrics(string candidateName,int &linesInputed){ //*2.-
    
     ifstream inputFileStream;  // Declare the input file stream
    // Open input file and verify that file was found
    inputFileStream.open( candidateName.c_str() );
    if( !inputFileStream.is_open()) {
        cout << "Could not find input file " << candidateName << "  Exiting..." << endl;
        exit( -1);
    }
    
    int numberOfLinesInFile = 0;
    inputFileStream >> numberOfLinesInFile;
    string line;
    int lining=rand()%numberOfLinesInFile;// Find a random number of the line.
    int lineCounter=1;//Count every line and if it equals the random number. cout or output.
    while( getline( inputFileStream, line) ) {
        if(lineCounter == lining){ //*3.-
          if ((line[0] != '#') && (line[0] != ' ')&& line.length()!=0){ // If it doesn't make sense dont output.
            cout << line << endl;
            
          } else {
            lining ++;    // Add to count so it goes 1 more up if errors.
          }
        }
        lineCounter++; // keep running till they equal.
    }
    inputFileStream.close();    // Close the input file.
}


/* CandidateQuiz function: Its the quiz that asks the user which candidate is correct of the lyrics.
 * If you enter into the program:
 * It will output:
 *1. Enter 1 for Trump, 2 for Warren:
 *2. Then it will wait for an answer.
 *3. Then it will compare the answer from the correct answer.
 *4. If you get the answer right it will: add to the score the same and add to the questions space and divide.
 *5.If you get the answer wrong it will: keep the score the same and add to the questions space and divide. 
 *6.The outputs*/

void CandidateQuiz(string candidateName, int correctAnswer,int &score,int &questions,int linesInputed){
    int answer=0;
    for (int i=0;i<linesInputed;i++){
    DisplayTheLyrics(candidateName,linesInputed); // for loop here
    }
    cout<<"Enter 1 for Trump, 2 for Warren: "; //1.-
    cin>>answer;  //2.-
    if(answer==correctAnswer){//3.-
      score=score+1;//4.-
      questions=questions+1;//4.-
      cout<<"Correct! You got "<<  score<<" out of "<< questions<<", which is "; //6.-
      cout<<fixed<< setprecision(0)<<(static_cast<double>(score)/static_cast<double>(questions))*100<<"%"<<endl;// You cant divide a int and another int
    }
    else{
      questions=questions+1;//5.-
      cout<<"Wrong! You got "<<  score<<" out of "<< questions<<", which is "; //6.- 
      cout<<fixed<< setprecision(0)<<(static_cast<double>(score)/static_cast<double>(questions))*100<<"%"<<endl;// Int/int=0 so I casted and *100 for %
    }
        return;
}
/* Where everything is at:
 * Menu
 * srand()
 * variables
 * exit()
 * number of lines choice
 * calls the functions*/

int main() {   
    srand(1);// Seed
    int i; // I was lazy so I declared i for all my loops.
    string candidateName=" ";//Trump or Warren
    int choice;//For when the program asks how many lines they want to see
    string trumpFile="Trump.txt";// Define each file
    string warrenFile="Warren.txt";// Define each file
    int linesOfLyrics = 3;//Define it first in case they just want to start the program
    int score=0;// If they exit it goes to 0
    int questions=0;// If they exit it goes to 0
    while(choice!=5){// While they dont exit, keep going.
        cout << endl
		 << "----  Program 2: Rally Songs  ----\n"
		 << "Select from the following:\n"
		 << "   1. Set number of lines to display\n"
		 << "   2. Get random lines from Trump.txt\n"
		 << "   3. Get random lines from Warren.txt\n"
		 << "   4. Rally song quiz\n"
		 << "   5. Exit the program\n"
         << "Your choice --> ";
     cin>>choice;
     cout<<"\n\n";
        
    if(choice==1){//How many lines does the user want to see throughout the choices
       cout<<"Enter the number of lines you want to display -> ";
        cin>>linesOfLyrics; //How many lines does user want? Keep it till the end.
    }
    else if (choice==2){//Set the file to Trump and find random lyrics
        for(i=0;i<linesOfLyrics;i++){
        DisplayTheLyrics(trumpFile,linesOfLyrics);
        }
    }
    else if (choice==3){//Set the file to Warren and find random lyrics
        for(i=0;i<linesOfLyrics;i++){
        DisplayTheLyrics(warrenFile,linesOfLyrics);
        }
    }
    else if (choice==4){// The quiz
    int randomize=(rand()%2)+1;//Choose 1 for Trump or 2 for Warren
        if (randomize==1){//Trump was picked. So it grabs lyrics from Trump.txt
            candidateName=trumpFile;
            CandidateQuiz(candidateName,randomize,score,questions,linesOfLyrics);
        }
        else {//Warren was picked. so it grabs lyrics from Warren.txt
            (candidateName=warrenFile);
            CandidateQuiz(candidateName,randomize,score,questions,linesOfLyrics);
    }
    }
    
    else if (choice==5){//Exit program

    if(questions==0){//If they exit first 0/0 is not 0
            cout<<"You got "<<  score<<" out of "<< questions<<", which is " 
          << 0<<"%"<<endl;
    }    else{//Get from the top to get the score and questions
          cout<<"You got "<<  score<<" out of "<< questions<<", which is "; 
          //***Park: You can simply use "cout << fixed << setprecision( 0) << valueToDisplay << "%" << endl;"
          //         This information is on the course website under the assignment 2 tab. 
          cout<<fixed<< setprecision(0)<<(static_cast<double>(score)/static_cast<double>(questions))*100<<"%"<<endl;// Int/int=0 so I casted and *100 for %
    }
        exit(-1);
        
    }
    else{//If user makes a mistake go back or invalid choice. Not 1-5.
        cout<<"Error: Incorrect selection, only choices 1-5.";
    }
    
} return 0;//end main()
}
 

//***Park: Really nice indentation and coding style. 