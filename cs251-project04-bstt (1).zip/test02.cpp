/*test02.cpp*/

//
// Unit tests for threaded binary search tree
//

#include <iostream>
#include <vector>

#include "bstt.h"

#include "catch.hpp"

using namespace std;


TEST_CASE("(2) Insert and Require") 
{
  bstt<int, int>  tree;
  int value;
  int key;
  tree.insert(100,20);
  REQUIRE(tree.size() == 1);
  REQUIRE(tree.search(100,value));
  REQUIRE(value==20);
  REQUIRE(tree.search(100,value)==true);
  tree.insert(20,30);
  REQUIRE(tree.search(20,value)==true);
  REQUIRE(tree.size()==2);
  tree.insert(102,45);
  tree.insert(300,24);
  REQUIRE(!tree.search(30,value));
  REQUIRE(tree[20] == 30);
  REQUIRE(tree(20)==100);
  REQUIRE(tree(100)==102);
  REQUIRE(tree(102)==300); 
  tree.begin();
  while(tree.next(key))
      cout<<key<<endl;
  tree.clear();
  REQUIRE(tree.size()==0);
 
  
}