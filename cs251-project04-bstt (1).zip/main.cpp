#include <iostream>

#include "bstt.h"

#include "catch.hpp"
#include<fstream>
using namespace std;


int main()
{
  ofstream i;
  i.open("Hello.txt");
  bstt<int, int>  tree;
  bstt<int,int> tree1;
  tree.insert(100,20);
  tree.insert(40,30);
  tree.insert(30,20);
  tree.insert(10,60);
  tree.insert(127,75);
  tree.insert(46,56);
  tree.insert(120,32);
  tree1.insert(90,44); 
  tree1.insert(30,20);
  tree1.insert(15,32);
  tree1.insert(50,300);
  tree1.insert(8,90);
  tree1.insert(25,12);
  tree1.insert(28,65);
  tree1.insert(20,45);
  tree1.insert(70,20);
  tree1.insert(60,32);
 tree=tree1;
  tree.dump(i);
  tree1.dump(i);
  return 0;
}