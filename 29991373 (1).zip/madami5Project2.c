/*Michael Adami
 * CS 211
 * Project 2
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TRUE 1
#define FALSE 0
int DebugMode;
typedef struct StackStruct
{
    char*    darr;  /* pointer to dynamic array  */
    int     allocated;  /* amount of space allocated */
    int     inUse; /* top of stack indicator - counts how many values are on the stack   */
} Stack;
/*To start our stack*/
void init (Stack* s){
    s->allocated= 2;
    s->darr = (char*) malloc ( sizeof (char) * s->allocated);
    s->inUse  = 0;
}
/*Used later in the program to check whether it is empty or not when we get the stack*/
int isEmpty (Stack* s){//checking if the stack is empty
    if ( s->inUse == 0)
        return TRUE;
    else
        return FALSE;
}
/* We push everything to stack so we can get the language we need to decrypt.*/
void push (Stack* s,char val){// check if enough space currently on stack and grow if needed
    if(s->inUse==s->allocated){ // If we ran out of space.
        if (DebugMode == TRUE)
            printf("The old size of array: %d", (s->allocated / sizeof(char))); // Check old size
        char* v = s->darr;
        s->darr = (char*) malloc (sizeof(char) * s->allocated+1); // Add an extra 1
        for(int i=0;i<s->allocated;i++){
            s->darr[i]=v[i];
        }
        free(v);
        s->allocated=s->allocated+1;
        if (DebugMode == TRUE)
            printf("\nThe new size of array: %d\n", (s->allocated / sizeof(char)));
    }
    s->darr[s->inUse]=val;

    s->inUse=s->inUse+1;
}
/*We want to remove if we get the second language letters*/
void pop (Stack* s){//removing an element off of the stack
    s->inUse = s->inUse - 1;
}

int top (Stack* s){//accessing the top element on the stack
    return (s->darr[s->inUse-1] );
}
/*Reset button to the end of every string*/
void clear(Stack *s){//clear the stack so that it is empty and ready to be used again
    free(s->darr);
    init(s);
    }

/*We used this function to update the new string from main*/
 void RemoveExtraLetters(char *str){
     char language0[4] = {'a', 'b', 'c', 'd'};// First language
     for (int i = 0; i < strlen(str); i++) { // Get all the letters
         for (int j = 0; j < 4; j++) { // Try every letter
             if (str[i] == language0[j]) { //If they are there input
                 printf("%c", language0[j]);
             }
         }
     }
 }

int main(int argc, char const *argv[]){

    char input[300];
    DebugMode = FALSE;
    for (int i = 0; i < argc; i++)
        if (strcmp(argv[i], "-d") == 0)
            DebugMode = TRUE;
    Stack s; //calling the struct
    init(&s);
    while (1){ //infinite loop
        printf ("\nEnter input to check or q to quit\n");/* get line of input from standard input */
        fgets(input, 300, stdin);
        /* remove the newline character from the input */
        int i = 0;
        while (input[i] != '\n' && input[i] != '\0'){
            i++;
        }
        input[i] = '\0';
        if ((strcmp (input, "q") == 0) || (strcmp (input, "Q") == 0))/* check if user enter q or Q to quit program */
            break;
        // printf ("%s\n", input);
        /*Start tokenizing the input into words separated by space
        We use strtok() function from string.h*/
        /*The tokenized words are added to an array of words*/
        char delim[] = " ";
        char *ptr = strtok(input, delim);
        int j = 0 ;
        char *wordList[15];
        while (ptr != NULL){
            wordList[j++] = ptr;
            ptr = strtok(NULL, delim);
        }
        char *letter;
        //printf("Decoded: ");
        for(int row=0;row<j;row++){
            letter=wordList[row]; // Get each word
            for(int col=0;col<strlen(wordList[row]);col++){
                char x=*letter; //Change it to make it more specific
                if(x=='a'||x=='b'|| x=='c'||x=='d'){ //In the language
                    push(&s,wordList[row][col]); //Push it to get removed later
                    if(DebugMode==TRUE){ //We want to find whether the correct thing was pushed.
                        printf("\nThe letter %c was pushed to stack",top(&s));
                    }


                    letter++;
                    //printf("%c ",top(&s));
                }
                
                else if((x =='m' && top(&s)=='a')|| (x=='n'&& top(&s)=='b')|| (x=='o'&& top(&s)=='c') || (x=='p' && top(&s)=='d')){ //If this is on the top and it is current
                        //printf("%c",x);
                        pop(&s); //Remove everything
                        letter++;
                        if(DebugMode==TRUE)
                            printf("\nThe letter %c removes the first letter in the stack by the rules",x);
                 }
                else{
                    letter++;
                }
            }
            if(isEmpty(&s)){ //We have a working string and we should add it
                RemoveExtraLetters(wordList[row]); //We have a clear stack change it to make sense.
                printf(" ");
            }
            else{ // If not found empty stack
                //printf("Not valid");
                clear(&s); //Reset the stack
            }
        }
        printf("\n");

    }
    printf ("\nGoodbye\n");
    return 0;
}