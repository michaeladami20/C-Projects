/*bstt.h*/

/*mymatrix.h*/

// 

// Michael J Adami III

// U. of Illinois, Chicago

// CS 251: Spring 2020

// Project #04

//

// Threaded binary search tree: A threaded binary search tree is a data structure that makes traversal through

// data easier than a regular binary tree. This class uses the function gets the first node(Begin), the next node(next),

// search, and clear with many different datas. 

//

// 


#pragma once


#include <iostream>


using namespace std;


template<typename KeyT, typename ValueT>
class bstt
{
private:
  struct NODE

  {
    KeyT   Key;
    ValueT Value;
    NODE*  Left;
    NODE*  Right;
    bool   isThreaded;
  };

  NODE* NextNODE;
  NODE* Root;  // pointer to root node of tree (nullptr if empty)
  int   Size;  // # of nodes in the tree (0 if empty)
  
  /* Deletes every node in the tree. Used for the destructor and the clear function*/

  void _postorder(NODE* cur){ 
     if(cur == nullptr)
        return;
     else{
          _postorder(cur->Left);
          if(!cur->isThreaded)
            _postorder(cur->Right);
        delete cur;
        Size--;
      }
  }     
  
  /*Helper for the dump(), which just checks the next node and prints to file*/
  void _dump(NODE* cur,ostream &output)const{
      if(cur==nullptr){
         return;
          }
      else{
         _dump(cur->Left,output);
          if(!cur->isThreaded || cur->Right==nullptr) //If not threaded keep going
              output<<"(" <<cur->Key << ","<<cur->Value << ")"<<endl;  
          else // Threaded 
              output<<"("<<cur->Key<<","<<cur->Value<<","<<cur->Right->Key<<")"<<endl;   
           }
         if(!cur->isThreaded)
             _dump(cur->Right,output); //Right side
      }
    /*Similiar to the search function but is a helper function to the () function*/
  NODE* _search2(KeyT key) const
  {
      NODE* cur = Root;
      while(cur!=nullptr){ // Keep going while there is something there.
         if (key == cur->Key && cur->Right!=nullptr){  // already in tree
            return cur;
         }         
         else if (key < cur->Key){ // search left:
            cur = cur->Left; //Keep going to the lowest
         }
         else{  //If the right is threaded just return nothing
             if(cur->isThreaded) 
              cur=nullptr;
             else //Nothing there exit
                cur=cur->Right;
            }
         }
    return nullptr;
  }
  /*This function copies the whole function of the copy constructor*/
  void _copy(NODE* copyRoot){
      if(copyRoot==nullptr){ // If nothing is on the tree return nothing
         return;
      }
      else{ //Not Empty
          insert(copyRoot->Key,copyRoot->Value); //Insert in tree
          _copy(copyRoot->Left); //Recursion 
          if(!copyRoot->isThreaded)
              _copy(copyRoot->Right); //Recursion
          }
      }

public:
  //
  // default constructor:
  //
  // Creates an empty tree.
  //

  bstt(){
    Root = nullptr;
    Size = 0;
  }
  //
  // copy constructor
  //
  bstt(const bstt& other){
    Size=0;
    Root=nullptr;
    _copy(other.Root);
    Size=other.Size;
  }
  //
  // destructor:
  //
  // Called automatically by system when tree is about to be destroyed;
  // this is our last chance to free any resources / memory used by
  // this tree.
  //
  virtual ~bstt(){
    _postorder(Root); // call to the helper function
  }
  
  //
  // operator=
  //
  // Clears "this" tree and then makes a copy of the "other" tree.
  //

  bstt& operator=(const bstt& other){
    if(this!=&other){
      clear();
      _copy(other.Root);
      }
      return* this;
  }
  //
  // clear:
  //
  // Clears the contents of the tree, resetting the tree to empty.
  //
  void clear(){
    _postorder(Root);
    Size=0;
    Root=nullptr;
  }
  // 
  // size:
  //
  // Returns the # of nodes in the tree, 0 if empty.
  //
  // Time complexity:  O(1) 
  //
  int size() const{
    return Size;
  }
  // 
  // search:
  //
  // Searches the tree for the given key, returning true if found
  // and false if not.  If the key is found, the corresponding value
  // is returned via the reference parameter.
  //
  // Time complexity:  O(lgN) on average
  //
  bool search(KeyT key, ValueT& value) const
  {
      NODE* cur = Root;
      while(cur!=nullptr){
         if (key == cur->Key){  // already in tree
            value=cur->Value;
            return true;
         }
         else if (key < cur->Key){  // search left:
            cur = cur->Left;
         }
         else{  //search right:
            if(cur->isThreaded){
               cur=nullptr;
            }
            else{
            // prev = cur;
            cur = cur->Right;
            }
         }
      }
    return false;
  }
  //
  // insert
  //
  // Inserts the given key into the tree; if the key has already been insert then
  // the function returns without changing the tree.
  //
  // Time complexity:  O(lgN) on average
  //
  void insert(KeyT key, ValueT value){
    NODE* prev = nullptr;
    NODE* cur = Root;
    //
    // 1. Search to see if tree already contains key:
    //
    while (cur != nullptr)
    {
      if (key == cur->Key)  // already in tree
        return;
      prev=cur;
      if (key < cur->Key){  // search left:
        cur = cur->Left;
      }
      else{
          if(cur->isThreaded){
              cur=nullptr;
            }
          else{
             cur = cur->Right;
          }     
      }
    }//while

    //
    // 2. if we get here, key is not in tree, so allocate
    // a new node to insert:
    // 
   NODE *n = new NODE(); //Make the new node to create
   n->Key= key; //Make the key equal to it
   n->Value=value; // Make the value equal to it
   n->Right=nullptr; // Left side is null
   n->Left =nullptr; // Right is null
   if(prev==nullptr){
      Root=n; //Make the node = the top
      n->Right=nullptr;
   }
   else{
     if(key<prev->Key){
         prev->Left=n; //Set the Left side the node
         n->Right=prev; //The right side the parent node
         n->isThreaded=true; //The right side to know its empty
     }
     else{
         n->Right=prev->Right; //Make the right node equal to the prev right node
         prev->Right=n; //change it to the new node
         prev->isThreaded = false; //Make sure it knows it has a child
         n->isThreaded=true; // No child
         }
    }
    //
    // 3. link in the new node:
    //
    // NOTE: cur is null, and prev denotes node where
    // we fell out of the tree.  if prev is null, then
    // the tree is empty and the Root pointer needs 
    // to be updated.
    //
    // 
    Size++;
    // 4. update size and we're done:
    //
  }
  
  // []
  //
  // Returns the value for the given key; if the key is not found,
  // the default value ValueT{} is returned.
  //
  // Time complexity:  O(lgN) on average

  ValueT operator[](KeyT key)const{
    ValueT value;
    if(search(key,value)){
        return value; //The next key
    }
    return ValueT{ }; //Default
  }
  
  // ()
  //
  // Finds the key in the tree, and returns the key to the "right".
  // If the right is threaded, this will be the next inorder key.
  // if the right is not threaded, it will be the key of whatever
  // node is immediately to the right.
  //
  // If no such key exists, or there is no key to the "right", the
  // default key value KeyT{} is returned.
  //
  // Time complexity:  O(lgN) on average
  //
  
  KeyT operator()(KeyT key) const{
      NODE* cur = Root;
      while(cur!=nullptr){ // Keep going while there is something there.
         if (key == cur->Key && cur->Right!=nullptr){  // already in tree
            return cur->Right->Key;
         }         
         else if (key < cur->Key){ // search left:
            cur = cur->Left; //Keep going to the lowest
         }
         else{  //If the right is threaded just return nothing
             if(cur->isThreaded) 
              cur=nullptr;
             else //Nothing there exit
                cur=cur->Right;
            }
         }
     return KeyT{};
  }

  //
  // begin
  //
  // Resets internal state for an inorder traversal.  After the 
  // call to begin(), the internal state denotes the first inorder
  // key; this ensure that first call to next() function returns
  // the first inorder key.
  //
  // Space complexity: O(1)
  // Time complexity:  O(lgN) on average
  //
  // Example usage:
  //    tree.begin();
  //    while (tree.next(key))
  //      cout << key << endl;
  
  void begin(){
      NextNODE=Root;
      if(NextNODE==nullptr)
          return;
      {
      while(NextNODE->Left != nullptr)
            NextNODE=NextNODE->Left; 
          }
      }
  
  // next
  //
  // Uses the internal state to return the next inorder key, and 
  // then advances the internal state in anticipation of future
  // calls.  If a key is in fact returned (via the reference 
  // parameter), true is also returned.
  //
  // False is returned when the internal state has reached null,
  // meaning no more keys are available.  This is the end of th
  // inorder traversal.
  //
  // Space complexity: O(1)
  // Time complexity:  O(lgN) on average
  //
  // Example usage:
  //    tree.begin();
  //    while (tree.next(key))
  //      cout << key << endl;
  //
  
  bool next(KeyT& key){
      if(NextNODE==nullptr){
          key=KeyT{};
          return false;
          }

      if (!NextNODE->isThreaded){ //If you can't go right make go right once.
          key=NextNODE->Key; //Remake the key= the other key
          NextNODE = NextNODE->Right; //Move Right
          while(NextNODE->Left!=nullptr)
              NextNODE=NextNODE->Left;
          return true;
       }
      else{ //If you can go right(Right then down)
          key=NextNODE->Key; //Key = the current node key
          NextNODE=NextNODE->Right; // Move Right
          return true; // Return Found
      }
  }
  
  //
  // dump
  // 
  // Dumps the contents of the tree to the output stream, using a
  // recursive inorder traversal.
  //

  void dump(ostream& output) const
  {
    output << "**************************************************" << endl;

    output << "********************* BSTT ***********************" << endl;

    output << "** size: " << this->size() << endl;

    // inorder traversal, with one output per line: either 
    // (key,value) or (key,value,THREAD)
    //
    // (key,value) if the node is not threaded OR thread==nullptr
    // (key,value,THREAD) if the node is threaded and THREAD denotes the next inorder key
    //
    _dump(Root,output);
    output << "**************************************************" << endl;

  }
};


