/*test01.cpp*/

//
// Unit tests for threaded binary search tree
//

#include <iostream>
#include <vector>

#include "bstt.h"

#include "catch.hpp"

using namespace std;


TEST_CASE("(1) empty tree") 
{
  bstt<int, int>  tree;
  bstt<int,int> tree1;
  int value;
  int key;
 tree.insert(100,20);
 tree1.insert(10,20);
 REQUIRE(tree.size() == 1);
  REQUIRE(tree.search(100,value));
  REQUIRE(value==20);
  REQUIRE(tree.search(100,value)==true);
  tree.insert(150,30);
  cout<<"The right of the tree is:" <<tree(100)<<endl;
  REQUIRE(tree[100]==20);
  REQUIRE(tree[150]==30);
  tree.insert(90,20);
  tree.insert(60,32);
  tree.insert(45,300);
  tree.insert(125,90);
  tree.insert(176,12);
  tree.insert(103,45);
  REQUIRE(tree(60)==90);
  REQUIRE(tree(45)==60);
  REQUIRE(tree(90)==100);
  REQUIRE(tree(103)==125);
  REQUIRE(tree(125)==150);
//   REQUIRE(tree(176)==0);
  tree.clear();
  tree.insert(30,20);
  tree.insert(15,32);
  tree.insert(50,300);
  tree.insert(8,90);
  tree.insert(25,12);
  tree.insert(28,65);
  tree.insert(20,45);
  tree.insert(70,20);
  tree.insert(60,32);
  REQUIRE(tree(8)==15);
 REQUIRE(tree(15)==25);
  REQUIRE(tree(20)==25);
  REQUIRE(tree(25)==28);
  REQUIRE(tree(28)==30);
  REQUIRE(tree(30)==50);
  REQUIRE(tree(50)==70);
  REQUIRE(tree(60)==70);
  REQUIRE(tree(70)==0);
  tree.begin();
  cout<<"Tree"<<endl;
  while(tree.next(key)){
      cout<<key<<endl;
//       cout<<"Value:";
//       cout<<tree[key]<<endl;
  }
     // tree=tree1;
  cout<<"Tree Size "<<tree.size()<<endl;
}
