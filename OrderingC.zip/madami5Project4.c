/*Michael J Adami III
 * UIN:656717220
 * CS 211
 * Project 4: This project gets customers orders and then removes them. It uses linked list to get the orders and stores them. Whether it be
 * called in or inside order. When they arrive you can change that and then take them out when the prepared burgers and salad are ready.
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef enum {FALSE = 0, TRUE, NO = 0, YES} boolean;

/* forward definition of functions */
void clearToEoln();
//Linked List struct
struct Node{
    char name[30];
    int burgers;
    int salads;
    int status;
    struct Node* next;
};
//Stack struct
struct node{
    char name1 [30];
    struct node* next;
};

//Start all the beginning
struct node* top=NULL;
//Push to stack
void push(char name [30]){
    struct node* ptr = (struct node*) malloc(sizeof(struct node));
    strncpy(ptr->name1, name, 30);
    ptr->next= top;
    top=ptr;
}
//Display it by popping it
void DisplayStack(char Name[30])
{
    struct node *temp;
    temp = top;
    if(temp==NULL){
        return;
    }
    int count=0;
    while (strncmp(temp->name1, Name,30)!= 0)
    {
        count++;
        printf("%d. %s\n",count, temp->name1);
        temp = temp->next;
    }
}

int Debug ;
//Check valid
int getNextNWSChar ()
{
    int ch;

    ch = getc(stdin);
    if (ch == EOF)
        return ch;
    while (isspace (ch))
    {
        ch = getc(stdin);
        if (ch == EOF)
            return ch;
    }
    return ch;
}

/* read in the next Positive Integer or error:    */
/* This is based on the Mathematical definition of a Postive Integer */
/*    zero is not counted as a positive number */
int getPosInt ()
{
    int value = 0;
    /* clear white space characters */
    int ch;
    ch = getc(stdin);

    while (!isdigit(ch))
    {
        if ('\n' == ch)  /* error \n ==> no integer given */
            return 0;
        if (!isspace(ch)) /* error non white space ==> integer not given next */
        {
            clearToEoln();
            return 0;
        }
        ch = getc(stdin);
    }
    value = ch - '0';
    ch = getc(stdin);
    while (isdigit(ch))
    {
        value = value * 10 + ch - '0';
        ch = getc(stdin);
    }
    ungetc (ch, stdin);  /* put the last read character back in input stream */
    /* Integer value of 0 is an error in this program */
    if (0 == value)
        clearToEoln();
    return value;
}

/* read in the name until the end of the input */
char *getName()
{
    /* skip over the white space characters */
    int ch;
    ch = getc(stdin);
    while (isspace(ch))
    {
        if ('\n' == ch)  /* error \n ==> no integer given */
            return NULL;
        ch = getc(stdin);
    }
    char *word;
    int size;
    size = 10;
    word = (char *) malloc (sizeof(char) * size);
    // read in character-by-character until the newline is encountered
    int count = 0;

    while (ch != '\n')
    {
        if (count+1 >= size)
        {
            // to grow an array to make it "dynamically sized" using malloc
            char* temp;
            int i;
            size = size * 2;
            temp = (char *) malloc (sizeof(char) * size);
            for (i = 0 ; i < count ; i++)
                temp[i] = word[i];
            free (word);
            word = temp;
        }
        word[count] = ch;
        count++;
        word[count] = '\0';
        // read next character
        ch = getc(stdin);
    }
    if (count > 30)
    {
        count = 30;
        word[count] = '\0';
    }
    /* clear ending white space characters */
    while (isspace (word[count-1]))
    {
        count--;
        word[count] = '\0';
    }
    return word;
}

/* Clear input until next End of Line Character - \n */
void clearToEoln()
{
    int ch;
    do {
        ch = getc(stdin);
    }
    while ((ch != '\n') && (ch != EOF));
}

/* Print out a list of the commands for this program */
void printCommands()
{
    printf ("The commands for this program are:\n\n");
    printf ("q - to quit the program\n");
    printf ("? - to list the accepted commands\n");
    printf ("a <# burgers> <# salads> <name> - to add your order to the order list\n");
    printf ("c <# burgers> <# salads> <name> - to add a call-ahead order to the order list\n");
    printf ("w <name> - to specify a call-ahead group is now waiting in the restaurant\n");
    printf ("r <# burgers> <# salads> - to retrieve the first waiting group whose order matches the items on the counter\n");
    printf ("l <name> - list how many orders are ahead of the named order\n");
    printf ("d - display the order list information\n");
    printf ("t <name> - display an estimated wait time for the given order name\n");
    /* clear input to End of Line */
    clearToEoln();
}

void addTo(struct Node** hd, int burgers,int salads, char *Name, boolean status)
{
    int stat = status;
    struct Node* ptr = (struct Node*) malloc (sizeof(struct Node));
    ptr->burgers = burgers;
    ptr->salads = salads;
    ptr->status = stat;
    strncpy(ptr->name, Name, 30);
    ptr->next = *hd;       /* note that hd must be "de-referenced" when used */
    *hd = ptr;             /*   the unary * operator is the "de-reference" operator */
}

int search(struct Node *hd, char* Name){
    struct Node *ptr = hd;
    while(ptr != NULL){
        if(strncmp(ptr->name, Name,30)== 0){
            ptr->status=1;
            return TRUE;
        }
        else{
            ptr=ptr->next;
        }
    }
    return FALSE;
}

int updateStatus(struct Node *hd, char* Name, boolean status){
    struct Node *ptr = hd;
    while(ptr != NULL){
        if(strncmp(ptr->name, Name,30)== 0){
                printf("The group is marked as being in the restaurant");
                ptr->status = status;
                return 1;
        }
        else{
            ptr=ptr->next;
        }
    }
    return 0;
}
// We use remove to remove the top element

void Remove (struct Node** hd, int burgers,int salads, boolean status)
{
    struct Node *cur, *prev;
    cur = *hd;
    while(cur!=NULL) {
        if (cur->burgers <= burgers && cur->salads <= salads && cur->status != FALSE) {  //Found the order
            push(cur->name);
        }
        cur=cur->next;
    }
    cur=*hd;
    prev=NULL;
    while(cur!=NULL){
        if(top==NULL)
            return;
        if(strncmp(cur->name,top->name1,30)==0){
                if (prev==NULL && cur->next==NULL){
                    *hd=cur->next;
                    free(cur);
                    free(prev);
                    free(top);
                    return;
                }
                else if(prev!=NULL && cur->next!=NULL){
                    prev->next=cur->next;
                    free(cur);
                    free(top);
                    return;
                }
                else{
                    prev->next=cur->next;
                    free(top);
                    free(cur);
                    return;
                }
        }
        else {
            prev = cur;
            cur = cur->next;
        }
        }

    }


void DisplayNameAhead ( struct Node* hd, char* Name ){
    printf("%s is behind:\n",Name);
    while (hd != NULL)
    {
        if(strncmp(hd->name, Name,30) != 0){
            return;
        }
        else {
            while (hd != NULL) {
                push(hd->name);
                hd = hd->next;
                if (hd == NULL)
                    break;
            }
        }
    }
}

void displayListInformation (struct Node* hd, boolean status)
{
    if (hd == NULL)
        return;

    // print the list after head node
    displayListInformation(hd->next, status);

    // After everything else is printed, print head
    printf ("  %s: %d Burgers, %d Salads", hd->name, hd->burgers, hd->salads);
    if(hd->status == TRUE){

        printf("( Waiting in restaurant ) \n");
    }
    else {
        printf("( Called in )\n");
    }
}

void doAdd (struct Node **hd, boolean status)
{
    /* get number of burgers ordered from input */
    int NumBurgers = getPosInt();
    if (NumBurgers < 0)
    {
        printf ("Error: Call-ahead command requires an integer value of at least 0\n");
        printf ("Call-ahead command is of form: c <# burgers> <# salads> <name>\n");
        printf ("where:<# burgers> is the number of ordered burgers\n");
        printf ("<# salads> is the number of ordered salads\n");
        printf ("<name> is the name of the person putting the order\n");
        return;
    }

    /* get number of salads ordered from input */
    int NumSalads = getPosInt();
    if (NumSalads < 0)
    {
        printf ("Error: Call-ahead command requires an integer value of at least 0\n");
        printf ("Call-ahead command is of form: c <# burgers> <# salads> <name>\n");
        printf ("where:<# burgers> is the number of ordered burgers\n");
        printf ("<# salads> is the number of ordered salads\n");
        printf ("<name> is the name of the person putting the order\n");
        return;
    }

    /* get group name from input */
    char *name = getName();
    if (NULL == name)
    {
        printf ("Error: Add command requires a name to be given\n");
        printf ("Add command is of form: a <# burgers> <# salads> <name>\n");
        printf ("where:<# burgers> is the number of ordered burgers\n");
        printf ("<# salads> is the number of ordered salads\n");
        printf ("<name> is the name of the person putting the order\n");
        return;
    }
    if (search(*hd, name) == TRUE) {
        printf("In-restaurant order for %s already exists.\n", name);
        return;
    }

    if(NumBurgers==0 && NumSalads==0){
        printf("Nothing has been ordered.");
        return;
    }
    else {
        printf ("Adding In-restaurant order for \"%s\": %d burgers and %d salads\n", name,NumBurgers ,NumSalads);
        addTo(hd, NumBurgers,NumSalads, name, status);
    }
    if (Debug == TRUE){
        printf("Debug activated \n");
    }
    if (Debug == TRUE){
        printf("%s, Current List: \n");
        displayListInformation(*hd, status);
    }
}
//When customer called ahead we mark the status as 0.
void doCallAhead (struct Node **hd, boolean status)
{
    /* get number of burgers ordered from input */
    int NumBurgers = getPosInt();

    if (NumBurgers < 0)
    {
        printf ("Error: Call-ahead command requires an integer value of at least 0\n");
        printf ("Call-ahead command is of form: c <# burgers> <# salads> <name>\n");
        printf ("where:<# burgers> is the number of ordered burgers\n");
        printf ("<# salads> is the number of ordered salads\n");
        printf ("<name> is the name of the person putting the order\n");
        return;
    }

    /* get number of salads ordered from input */
    int NumSalads = getPosInt();
    if (NumSalads < 0)
    {
        printf ("Error: Call-ahead command requires an integer value of at least 0\n");
        printf ("Call-ahead command is of form: c <# burgers> <# salads> <name>\n");
        printf ("where:<# burgers> is the number of ordered burgers\n");
        printf ("<# salads> is the number of ordered salads\n");
        printf ("<name> is the name of the person putting the order\n");
        return;
    }

    /* get group name from input */
    char *name = getName();
    if (NULL == name)
    {
        printf ("Error: Call-ahead command requires a name to be given\n");
        printf ("Call-ahead command is of form: c <# burgers> <# salads> <name>\n");
        printf ("where:<# burgers> is the number of ordered burgers\n");
        printf ("<# salads> is the number of ordered salads\n");
        printf ("<name> is the name of the person putting the order\n");
        return;
    }

    if (search(*hd, name) == TRUE){
        printf ("In-restaurant order for \"%s\" already exists.\n", name);
    }
    else {
        printf ("Adding Call-ahead order for \"%s\": %d burgers and %d salads\n", name,NumBurgers ,NumSalads);
        addTo(hd, NumBurgers,NumSalads, name, status);
    }
    if (Debug == TRUE){

        printf("%s, Current List: \n");
        displayListInformation(*hd, status);
    }
}

void doWaiting (struct Node* hd, boolean status) {
    /* get group name from input */
    char *name = getName();
    if (NULL == name) {
        printf("Error: Waiting command requires a name to be given\n");
        printf("Waiting command is of form: w <name>\n");
        printf("where: <name> is the name of the group that is now waiting\n");
        return;
    }
    if(search(hd,name)==1){
    printf("Waiting group \"%s\" is now in the restaurant\n", name);
    updateStatus(hd, name, status);
    }
    else
        printf("Name does not exist in the queue.\n");

    }


void doRetrieve (struct Node **hd, boolean status)
{
    /* get info of prepared food ready on the counter from input */
    int PreparedBurgers = getPosInt();
    if (PreparedBurgers < 0)
    {
        printf ("Error: Retrieve command requires an integer value of at least 0\n");
        printf ("Retrieve command is of form: r <# burgers> <# salads>\n");
        printf ("where: <# burgers> is the number of burgers waiting on the counter for pick up\n");
        printf ("<# salads> is the number of salads waiting on the counter for pick up\n");
        return;
    }

    int PreparedSalads = getPosInt();
    if (PreparedSalads < 0)
    {
        printf ("Error: Retrieve command requires an integer value of at least 0\n");
        printf ("Retrieve command is of form: r <# burgers> <# salads>\n");
        printf ("where: <# burgers> is the number of burgers waiting on the counter for pick up\n");
        printf ("<# salads> is the number of salads waiting on the counter for pick up\n");
        return;
    }

    clearToEoln();
    printf ("Retrieve (and remove) the first group that can pick up the order of %d burgers and %d salads\n", PreparedBurgers ,PreparedSalads);
    // add code to perform this operation here
    Remove(hd, PreparedBurgers,PreparedSalads, status);
    if(Debug == TRUE){
        printf("%s, Current List: \n");
        Remove(hd, PreparedBurgers,PreparedSalads, status);
    }
}

void doList (struct Node *hd, boolean status)
{
    /* get group name from input */
    char *name = getName();
    if (NULL == name)
    {
        printf ("Error: List command requires a name to be given\n");
        printf ("List command is of form: l <name>\n");
        printf ("where: <name> is the name of the group to inquire about\n");
        return;
    }

    if(search(hd,name)==1) {
        printf ("\"%s\" is behind the following orders\n", name);
        // add code to perform this operation here
        DisplayNameAhead(hd, name);
        DisplayStack(name);
    }
    else{
        printf("Does not exist in the queue.");
    }
    if(Debug == TRUE){
        printf("Current List: \n");
        displayListInformation(hd, status);
    }
}

void doDisplay (struct Node *hd, boolean status)
{
    printf("Orders:\n");
    // add code to perform this operation here
    displayListInformation(hd, status);

}

void doEstimateTime(struct Node *hd)
{
    /* get order name from input */
    struct Node* cur = hd;
    char *name = getName();
    if (NULL == name)
    {
        printf ("Error: List command requires a name to be given\n");
        printf ("List command is of form: t <name>\n");
        printf ("where: <name> is the name of the order to inquire about\n");
        return;
    }
    if(search(hd, name)==1){
        while (cur != NULL){
            if (strncmp(cur->name, name,30) == 0 ) {
                printf("Wait time for \"%s\": %d minutes", name, cur->burgers * 10 + cur->salads * 5);
            }
            cur=cur->next;
        }
    }
    else{
        printf("Name Does Not Exist in Queue.");
    }
}

int main (int argc, char **argv)
{
    struct Node *head = NULL;
    int ch;
    int i;
    for (i = 0; i < argc; i++)
    {
        if ('-' == argv[i][0]){
            if ('d' == argv[i][1]){
                Debug=TRUE;
            }
        }
        else {Debug=FALSE;}
    }

    printf ("Starting Restaurant Wait List Program\n\n");

    printf ("Enter command:");

    while ((ch = getNextNWSChar ()) != EOF)
    {
        /* check for the various commands */
        if ('q' == ch)
        {
            printf ("Quitting Program\n");
            return (0);
        }
        else if ('?' == ch)
        {
            printCommands();
        }
        else if('a' == ch)
        {
            doAdd(&head, TRUE);
        }
        else if('c' == ch)
        {
            doCallAhead(&head, FALSE);
        }
        else if('w' == ch)
        {
            doWaiting(head, TRUE);
        }
        else if('r' == ch)
        {
            doRetrieve(&head, FALSE);
        }
        else if('l' == ch)
        {
            doList(head, TRUE);
        }
        else if('d' == ch)
        {
            doDisplay(head, TRUE);

        }
        else if('t'== ch){
            doEstimateTime(head);
        }
        else if('\n' == ch)
        {
            /* nothing entered on input line     *
             * do nothing, but don't give error  */
        }
        else
        {
            printf ("%c - in not a valid command\n", ch);
            printf ("For a list of valid commands, type ?\n");
            clearToEoln();
        }
        printf ("\nEnter command:");
    }

    printf ("Quiting Program - EOF reached\n");
    return 1;
}

