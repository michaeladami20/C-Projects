#include <iostream> // io files
#include <fstream> // io files
#include <string> // string functions
#include <vector> // vectors used in prog
#include "ourvector.h" //get the vector
using namespace std;
/*This program is an email filter with 4 functions: load, display,check, and filter.
 * It also is running a binary search in the background to find the emails of spam and non-spam.
 * The functions that are relying on the binary searches are check and filter.
 */
/* binarySearch(): It requires any string and a ourvector string vector. We have already declared this before.
 * When running this function, the function finds whether the string is in the middle of the string vector. If not
 * then it goes up or down depending on whether it is bigger or smaller than the middle. If it is then we cut the 
 * search in half and get the string. Faster than linear search." 
 */
bool binarySearch(string word, ourvector <string> words)
{
	int hi = words.size()-1, lo = 0; //The outer bounds 
	while (lo <=hi) // if it is out of bounds end
		{
		   int mid=(hi+lo)/2; // set the center
		   string obj = words[mid]; // set the middle word
		   if (obj== word){ // if it is the word it worked
				return true; 
			}
			else if (obj < word){ //if the word is larger then go down
				lo=mid+1;
			}
			else{ // if the word is larger go up
	         hi=mid-1;
			}
		}
	return false; // we couldnt find it in the area
}
/* load(): It takes a filename, loads the contents and returns the string from pushing back the values from the filename
 * This is an important function for my program. When I run my check, display, and filter function it uses this function
 * one way or another. It returns the declared vector from before and then we use it every where else. 
 */
ourvector<string> load(string filename){
    ifstream infile(filename);
    ourvector<string> emails; // call our vector
    if (!infile.is_open()) {
      cout << "**Error, unable to open '"<<filename<<"'"<< endl<<endl; // Invalid file
      return emails;
   }
   cout<<"Loading '"<<filename<<"'"<<endl; // load for the certain output
    while (!infile.eof())
    {
       string email; // the email addresses
       infile >> email; // emails
       if (!infile.fail()) { //if it isnt end 
           emails.push_back(email); // push it in the email vector
       }
    }
    cout<<"# of spam entries: "<< emails.size()<<endl<<endl; // Show our entries
	return emails; //return vector
}
/* We use the display to show a what is inside the vector. It is like a fail safe for our function load().
 * When we push_back() contents to the vector, we want to see if everything was stored correctly. If not then
 * there must be something wrong with load function and that would cause problems for everything.
 */
void display(ourvector<string> emails){
    for (string s : emails){ //Run a loop to go through the contents
        cout << s << endl;   // Then output them on the screen.
    }
}
/* We use the ParseEmailAddress(): It takes the email inputed from the user and splits it and then points to the domain and user
 * so it can find the user and domain to compare them to the spam address used for check() and filter().
 */
string ParseEmailAddress(string email,string &tdomain, string &tusername){
    tusername =email.substr(0, email.find('@')); // find the user
    tdomain = email.substr(email.find('@')+1,email.length()); // find the domain
    return tdomain+':'+tusername;// make it into the correct version
}
/* ParseSpamEmail(): It takes the email from the spamfile and then loops from it and then gets the domain for all '*' usernames.
 * If it is a star then we can confirm that all domains from that is spam. It is used in the check() and filter() to check if the domains
 * are spam.
 */
string ParseSpamEmail(string email){
    string domain=email.substr(0, email.find(':')); // find the domain for the '*'
    return domain; // return it
}
/* Check(): This fuction takes and email and compares it to the filters used and compares the '*' and username.
 * If it is spam then it returns true and false if it is not spam.
 */
bool check(ourvector<string> emails,string email){
    string username; //hold the user
    string domain; // hold the domain
    string together; // group them
    together=ParseEmailAddress(email,domain,username); // declared up top so we stored it
    if(binarySearch(together,emails)||binarySearch((domain+":*"),emails)){ //if it is in spamfile.
        return true;
     }
    return false;
  }
/* Filter(): The filter function takes the input file name, vector, and the output file name. If it is not spam then it will input the
 * email inside of the output file from the input file with the number email and number.
 */
void filter(ourvector<string> emails,string ifilename, string ofilename){   // Open file
    ifstream infile(ifilename); // Input file
    ofstream outfile(ofilename); //Output file
    string num=""; // email number
    string email=""; //email 
    string subject=""; // subject of email
    int spamcount=0; // count the spam emails
    int nonspamcount=0; // count the emails not spam
    string emailDomain=""; // get the domain
    string emailUser=""; // get the username
    if (!infile.is_open()) {
        cout << "**Error, unable to open '"<<ifilename<<"'" << endl<<endl; //if it is not found return
        return;
    }
    if(!outfile.is_open()){
        cout << "**Error, unable to open '"<<ofilename<<"'" << endl<<endl; // if it is not found return
      return;
   }
    while(infile>>num>>email){
        getline(infile,subject); //get the email subject
        ParseEmailAddress(email,emailDomain,emailUser); //Change the email to domain and user
        string convert=emailDomain+":"+emailUser; //Change the email to correct format
        if (binarySearch(convert,emails)||binarySearch((emailDomain+":*"),emails)) { //See if it is spam or not
            spamcount++; //if spam add to spam count
        } 
        else{
            outfile<<num<<" "<<email<<subject<<endl; //input to file and put it in the format before
            nonspamcount++; // add to non spam count
        }
      }
    infile.close();// close input file
    outfile.close();// close output file
    cout<<"# emails processed: "<<nonspamcount+spamcount<<endl; // total emails
    cout<<"# non-spam emails:  "<<nonspamcount<<endl<<endl; //total nonspam
}
/* main(): The glue to piece all of the functions together. It contains the selections,
 * and the functions calls. It keeps running until the user enter # which exits the program.
 * 
 */
int main(){
   string filename; //filenames
   ourvector<string> emails; // declared our spam vector 
   string selection; //the choice
   string emailCheck; // Checks the sent email
   cout<<"** Welcome to spam filtering app **"<<endl<<endl; // Intro
   while(true){ // inf loop
       cout << "Enter command or # to exit> ";
       cin>>selection;
       if(selection=="load"){ // load the spamfiles
           cin.ignore();
           getline(cin,filename);// input filename:
           filename=filename.substr(0,filename.find(" ")); //Gets line and sets it as filename
           emails=load(filename);
           continue;
       }
       else if(selection=="display"){ // if they want to display the file
          display(emails);
          cout<<endl;
          continue;
        }
       else if(selection=="check"){ // If user selects check we check the email for spam or not.
             cin>>emailCheck;
             if(check(emails,emailCheck)){ // If it comes out true return the spam
                 cout<<emailCheck<<" is spam"<<endl<<endl;
             }
             else{ //If it comes out false return not spam
                  cout<<emailCheck<<" is not spam"<<endl<<endl;
             }
             continue;
       }
       else if(selection=="filter"){ // filter and output file
            string ifilename;
            string ofilename;
            cin>>ifilename;// input infilename
            cin>>ofilename;// input outfilename
            filter(emails,ifilename,ofilename); // go to function
            continue;
       }
       
       else if(selection=="#"){ //exit out
           exit(0);
           cout<<endl;
       }
       else{ // If the command is not an option output and continue.
           cout<<"**invalid command"<<endl<<endl; //if the command not in list redo string
           continue;
       }
   }
   return 0;
}
