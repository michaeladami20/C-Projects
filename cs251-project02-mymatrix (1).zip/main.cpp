#include <iostream>
#include <string>
#include "mymatrix.h"

using namespace std;

bool size_test1(mymatrix<int>  M){
     // creates 4x4 matrix
      cout<<"size:"<<endl<<endl<<M.size()<<endl;
      if (M.size()== 16)
          return true;
      else
          return false;
      }


int main(){
  mymatrix<int>  M;  // 4x4 matrix, initialized to 0
  mymatrix<int> M3;
  mymatrix<int> M1;
  mymatrix<int> M4;
  mymatrix<int> M2;
  mymatrix<char> MC;
  M(0, 0) = 3;
  M(1, 1) = 4;
  M(2, 2) = 5;
  M(3, 3) = 6;
  M2=M;
  M2._output();
  cout<<endl;
  M._output();
  cout<<endl<<M.at(0,0)<<endl<<endl;
  M2.growcols(1,4);  // increase # of cols in row 1 to 8
  cout<<"Size is: "<<M.size()<<endl<<endl;
  cout<<"Num Cols size: "<<M.numcols(2)<<endl<<endl;
    for(int i=0;i<4;i++){
        for(int j=0;j<4;j++){
            M2(i,j)=j;
        }
    }
    cout<<endl<<endl;
    M2._output();
    M4=M2*M2;
    cout<<endl<<endl;
    M4._output();
    //M.growcols(5,5);
    M1=(M*2);
    MC=MC*2;
    MC._output();
    M2=(M*19);
    M2._output();//Scalar Mult
    M._output();
    M1._output();
    cout<<endl<<endl;
    M3=M*M1;     //Matrix Mult
    M3._output();
    cout<<endl;
    M.grow(4,4);
    M._output();
  cout<<"num Cols"<< M.numcols(1)<<endl;
  
    
    int passed = 0;
    int failed = 0;
    if (size_test1(M))
        passed++;
    else {
          cout << "size_test1 failed" << endl;
          failed++;
         }
    cout << "Tests passed: " << passed << endl;
    cout << "Tests failed: " << failed << endl;
    return 0;
}