 void grow(int R, int C){
    if (R < 1)
      throw invalid_argument("mymatrix::grow: # of rows");
    if (C < 1)
      throw invalid_argument("mymatrix::grow: # of cols");
    if(NumRows<R){
    ROW* newRow = new ROW[R]; // an array with elements of type T:
    
   for (int r = 0; r < numrows(); ++r)
    {
       T* newCols = new T[C];
      for (int c = 0; c < numcols(r); c++){
        newRow[r].Cols[c] = Rows[r].Cols[c];
        }
        for(int r=0;r<numrows();r++){
        delete[] Rows[r].Cols;
        }
        for(int r=0;r<R;r++){
        if(numcols(r)==C){
        Rows[r].Cols = newRow[r].Cols;  // default value for type T:
        Rows[r].NumCols = C;
          }
         }
    }
      // initialize the elements to their default value:
    NumRows = R;
    }
  }