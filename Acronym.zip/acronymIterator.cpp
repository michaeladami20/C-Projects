//
// Project 1
// CS 341 Spring 2021
// Michael Adami
//
// Populate this file with the function definitions for the acronymIterator class

#include "acronymIterator.h"

 characterParser::acronymIterator::acronymIterator(char* arr) {
    int count=0;
    char* newarr;
    while(*arr!='\0'){
        if(isalpha(*arr)){
            break;
        }
        count++;
        arr++;
    }
//     newarr=new char[(strlen(arr)-count)+1];
//     strncpy ( newarr, arr+count, strlen(arr)-count) ;
     curr=arr;
}

char& characterParser::acronymIterator::operator*()
{
    return *curr;
}

characterParser::acronymIterator& characterParser::acronymIterator::operator++()
{
    while((!isspace(*curr) || !ispunct(*curr) ) && *curr!='\0'){
        curr++;
        if((isspace(*curr) || *curr=='(' || *curr=='"') ) {
            curr++;
            if(*curr==':'){
                continue;
            }
            if (isalpha(*curr)) {
                *curr;
                break;
            }
            while(!isalpha(*curr) && *curr!='\0') {
                curr++;
            }
            break;
        }
    }
    return *this;
}

bool characterParser::acronymIterator::operator!=(const characterParser::acronymIterator& other)
{
    return curr != other.curr;
}

bool characterParser::acronymIterator::operator==(const characterParser::acronymIterator& other)
{
    return curr == other.curr;
}