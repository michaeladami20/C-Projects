//
// Project 1
// CS 341 Spring 2021
// Michael Adami
//
//Populate this file with the functions definitions for the acronymIterator class

#pragma once
#include <iterator>
#include "characterParser.h"
#include<queue>
class characterParser::acronymIterator
{
public:
    using iterator_category = std::forward_iterator_tag;
    using value_type = char;
    using difference_type = std::ptrdiff_t;
    using pointer = char*;
    using reference = char&;

private:
    char* curr{};
    std::queue<char*> a;
public:
    acronymIterator(char* arr);

    char& operator*();

    acronymIterator& operator++();

    bool operator!=(const acronymIterator& other);

    bool operator==(const acronymIterator& other);

};


