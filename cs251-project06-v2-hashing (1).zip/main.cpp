/*main.cpp*/

//
// Michael Adami
// U. of Illinois, Chicago
// CS 251: Spring 2020
// 
// Project 6 Part 2: DIVVY Program
// 

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <ctype.h>
#include <vector>
#include "util.h"
#include "hash.h"
#include "hashmap.h"
#include <algorithm>
#include<set>
using namespace std;

//
// StationData
// 
// Information from the stations.csv
// abbrev+id+fullname+latitude+longitude+capacity+onlineDate.
// Keys-ID or abbrev
// Values-fullname, latitude, cap, longitude, onlineDate
// 

struct StationData
{
    string abbrev;
    string id;
	string fullname;
    float latitude;
    float longitude;
    int cap;
    string onlineDate;
	
	StationData()
	{
        id="";
        abbrev="";
		fullname = "";
		latitude = 0.0;
        longitude= 0.0;
        cap=0;
        onlineDate = "";
	}
};

// Third Hashmap
// The data is from the trips.csv file
// This data contains the tripID,start,start, bike id,duration in seconds, from, to, MaleOrFemale,BirthYear
struct tripData
{
    string start;
    string stop;
    string bid;
    int duraSec;
    string from;
    string to;
    string mOf;
    string BY;
    tripData(){
        start="";
        stop="";
        bid="";
        duraSec=0;
        from="";
        to="";
        mOf="";
        BY="";
    } 
};

class ordering
{
    public:
    bool operator()(const pair<string,double>& p1,const pair<string,double>& p2)const{
        return p1.second<p2.second;
    }
};

//
// string2int
// 
// Converts a string to an integer, unless string is empty, in
// which case 0 is returned.
// 
int string2int(string s)
{
	if (s == "")
		return 0;
	else
		return stoi(s);
}

//
// inputData
// 
// Given a filename denoting lottery winning numbers,
// inputs that data into the given hash table.
// 

bool inputDataTrip(string filename,string filename1, hashmap<string, StationData>& hmap,hashmap<string,StationData>& hmap1, hashmap<string,tripData>& hmap2,hashmap<string,int>& hmap3)
{
	cout <<endl<< "Reading " << filename << endl;
    cout <<"Reading " << filename1 << endl<<endl;
	ifstream infile(filename);
	int numBikes=0;
	if (!infile.good())
	{
		cout << "**Error: unable to open '" << filename << "'..." << endl;
		return false;
	}
	
	// file is open, start processing:
	string line;
	
	getline(infile, line);  // input and discard first row --- header row
	
	int scount = 0;
	while (getline(infile, line))
	{
		stringstream s(line);
		string id,abbrev,fullname,latitude,longitude,cap,onlineDate;
        
		getline(s, id, ',');  // first value 
		getline(s, abbrev, ',');   // second values
		getline(s, fullname, ',');
		getline(s, latitude, ',');
        getline(s, longitude,',');
        getline(s, cap,',');
        getline(s, onlineDate,',');
		
		// we have input the 4 values, and since we are not
		// doing any arithmetic, we can just store them as
		// strings.  If the multiplier is missing then the
		// string is "", which is fine.
		int capI=string2int(cap);
        float latitudeF=stof(latitude);
        float longitudeF=stof(longitude);
		//
		// store into hash table
		// 
		StationData sd;
        sd.id=id;
        sd.abbrev = abbrev;
		sd.fullname = fullname;
		sd.latitude = latitudeF;
		sd.longitude = longitudeF;
        sd.cap=capI;
        sd.onlineDate=onlineDate;
		hmap.insert(id, sd, Hash);
        hmap1.insert(abbrev,sd,Hash);
		scount++;
	}
	cout << "# of stations: " << scount << endl;
    
    ifstream infile1(filename1);
    if (!infile1.good())
	{
		cout << "**Error: unable to open '" << filename1 << "'..." << endl;
		return false;
	}
	// file is open, start processing:
	getline(infile1, line);  // input and discard first row --- header row
	int tcount = 0;
	while (getline(infile1, line))
	{
		stringstream s(line);
		string trid,start,stop,duraMin,duraSec,from,to,bid,mOf,BY;
        //Get the values from the csv
		getline(s, trid, ',');  // first value => region
		getline(s, start, ',');   // second value => country
		getline(s, stop, ',');
		getline(s, bid, ',');
        getline(s,duraSec,',');
        getline(s,from,',');
        getline(s,to,',');
        getline(s,mOf,',');
        getline(s,BY);
		// we have input the 4 values, and since we are not
		// doing any arithmetic, we can just store them as
		// strings.  If the multiplier is missing then the
		// string is "", which is fine.
        int duraSI=string2int(duraSec);
        
		//
		// store into hash table
		// 
		tripData td;
		td.start = start;
		td.stop = stop;
        td.bid=bid;
        
        td.duraSec=duraSI;
		td.from= from;
        td.to=to;
        td.mOf=mOf;
        td.BY=BY;
        int bike=0;
        
        if(hmap3.search(bid,bike,Hash)){
           int usage=bike+1;
           hmap3.insert(bid,usage,Hash);
        }
        else{
            hmap3.insert(bid,1,Hash);
            numBikes++;
        }
        hmap2.insert(trid, td, Hash);
		tcount++;
	}
	cout << "# of trips: " << tcount << endl;
    cout<< "# of bikes: " << numBikes<<endl;
	return true;  // we have data to be processed:
}

int main()
{
	cout << "** DIVVY analysis program **" << endl;
	cout << endl;
	const int N = 2000;
	hashmap<string, StationData> hmap(N);
    hashmap<string,StationData> hmap1(N);
    hashmap<string,tripData> hmap2(N);
    hashmap<string,int> hmap3(N);
	string filename = "";
    string filename1= "";
    cout<<"Enter stations file> ";
    cin>>filename;
	cout<<"Enter trips file> ";
    cin>>filename1;
    
	bool success = inputDataTrip(filename,filename1,hmap,hmap1,hmap2,hmap3);
	//
	// did we input anything?
	// 
	if (!success)
	{
		cout << "No data, file not found?" << endl;
		return 0;
	}

	//
	// allow the user to lookup winning numbers by date:
	// 
	string id;
    string command;
    cin.ignore();
    cout<<endl;
	cout << "Please enter a command, help, or #> ";
    getline(cin, command); // skip the first new line after N.
	//
	// user testing:
	//
	while (command != "#")
    {  
    string fCommand;
    vector<pair<string, float>> vect;
    vector<string> vect1;
    vector<string> vect2;
    vector<pair<string, string>> vector3;
    stringstream s(command);
    getline(s,fCommand,' ');
    StationData sd;
    tripData td;
    int bikes=0;
    StationData gd;
    if(fCommand=="help"||fCommand=="Help"){
        cout<<"Available commands:"<<endl;
        cout<<" Enter a station id (e.g. 341)"<<endl;
        cout<<" Enter a station abbreviation (e.g. Adler)"<<endl;
        cout<<" Enter a trip id (e.g. Tr10426561)"<<endl;
        cout<<" Enter a bike id (e.g. B5218)"<<endl;
        cout<<" Nearby stations (e.g. nearby 41.86 -87.62 0.5)"<<endl;
        cout<<" Similar trips (e.g. similar Tr10424639 0.3)"<<endl;
    }
    //If the string isNumeric then we can perform the id
    else if(isNumeric(fCommand)){
        if(hmap.search(fCommand,sd,Hash)){
            cout<<"Station:"<<endl;
            cout<<" ID: "<<fCommand<<endl;
            cout<<" Abbrev: "<<sd.abbrev<<endl;
            cout<<" Fullname: "<<sd.fullname<<endl;
            cout<<" Location: ("<<sd.latitude<<", "<<sd.longitude<<")"<<endl;
            cout<<" Capacity: "<<sd.cap<<endl;
            cout<<" Online date: "<<sd.onlineDate<<endl;
        }
        else
            cout<<"Station not found"<<endl;
    }
    else if(fCommand[0]=='T'&&fCommand[1]=='r' && isdigit(fCommand[2])){
        if(hmap2.search(fCommand,td,Hash)){
            cout<<"Trip:"<<endl;
            cout<<" ID: "<<fCommand<<endl;
            cout<<" Starttime: " << td.start << endl;
            cout<<" Bikeid: " << td.bid << endl; 
            cout<<" Duration: "<< td.duraSec/60<<" minutes, "<<td.duraSec%60<<" seconds"<<endl;
            hmap.search(td.from,sd,Hash);
            cout<<" From station: "<<sd.abbrev<<" ("<<td.from<<")"<<endl;
            hmap.search(td.to,sd,Hash);
            cout<<" To station: "<<sd.abbrev<<" ("<<td.to<<")"<<endl;
            cout<<" Rider identifies as: "<<td.mOf<<endl;
            cout<<" Birthyear: "<<td.BY<<endl;
        }
        else{
            cout<<"Trip not found"<<endl;
        }
    }
    // Count the amount of rides that the person has been on
    else if(fCommand[0]=='B' && isdigit(fCommand[1])){
        if(hmap3.search(fCommand,bikes,Hash)){
            cout<<"Bike:"<<endl;
            cout<<" ID: "<<fCommand<<endl;
            cout<<" Usage: "<<bikes<<endl;
        }
        else{
            cout<<"Bike not found"<<endl;
        }
    } 
    // Given a range and a distance then you have to give a range and function will find closest
    // station nearby
    else if(fCommand=="nearby"){
        double rangeOLaditude=0.0;
        double rangeOLongitude=0.0;
        double distance=0.0;
        string rangeOLongitudeS,rangeOLaditudeS,distanceS;
        getline(s,rangeOLaditudeS,' ');
        getline(s,rangeOLongitudeS,' ');
        getline(s,distanceS,' ');
        //After nearby we input the range,and the distance
        distance=stod(distanceS);
        rangeOLongitude=stod(rangeOLongitudeS);
        rangeOLaditude=stod(rangeOLaditudeS);
        cout<<"Stations within "<<distance<< " miles of ("<<rangeOLaditudeS<<", "<<rangeOLongitudeS<<")"<<endl;
        for(unsigned int i=0;i<hmap.getKeys().size();i++){
            if(hmap.search(hmap.getKeys()[i],sd,Hash)){
            double differ=distBetween2Points(rangeOLaditude,rangeOLongitude,sd.latitude,sd.longitude);
            if(differ<=distance){
                vect.push_back(make_pair(hmap.getKeys()[i],differ));
            }

           }  
        }          
        sort(vect.begin(),vect.end(),ordering());
        if(vect.size()!=0)
            for( unsigned int i=0;i<vect.size();i++){
                cout<<" station "<<vect[i].first<<": "<<vect[i].second<<" miles"<<endl;
            }
        
        else{
            cout<<" none found"<<endl;
        }
        vect.erase(vect.begin(),vect.end());
    }
//     else if(fCommand=="similar"){
//       string trip="";
//       string milesS="";
//       string fCommand="";
//       float miles; 
//       int tripC=0;
//       float differ=0.0;
//       getline(s,trip,' ');
//       getline(s,milesS,' ');
//       miles=stof(milesS);
//       cout<<"Trips that follow a similar path (+/-"<<miles<<" miles) as "<<trip<<endl;
//       if(hmap2.search(trip,td,Hash)){
//           if(hmap.search(td.from,gd,Hash)){
//               for(size_t i=0;i<hmap.getKeys().size();i++){
//                 if(hmap.search(hmap.getKeys()[i],sd,Hash)){
//                     differ=distBetween2Points(sd.latitude,sd.longitude,gd.latitude,gd.longitude);       
//                 if(differ<=miles){
//                     vect1.push_back(hmap.getKeys()[i]);
//                 }
//                }  
//             }          
//         }
//        if(hmap.search(td.to, gd,Hash)){
//               for(size_t i=0;i<hmap.getKeys().size();i++){
//                 if(hmap.search(hmap.getKeys()[i],sd,Hash)){
//                     differ=distBetween2Points(sd.latitude,sd.longitude,gd.latitude,gd.longitude);       
//                 if(differ<=miles){
//                     vect2.push_back(hmap.getKeys()[i]);
//                 }
//                }  
//             }   
//        }
//     set<string> startS;
//     set<string> endS;
//     for(size_t i=0;i<vect1.size();i++){
//         startS.insert(vect1[i]);
//     }
//     for(size_t i=0;i<vect2.size();i++){
//         endS.insert(vect2[i]);
//     }
// //           sort(vect1.begin(),vect1.end(),ordering());
// //           sort(vect2.begin(),vect2.end(),ordering());
//         for(size_t i=0; i<vect1.size();i++)
//             cout<<" nearby starting points"<<vect1[i]<<endl;
//         for(size_t i=0; i<vect2.size();i++)
//             cout<<" nearby ending points"<<vect2[i]<<endl;
//       vector<string> trips= hmap2.getKeys();
//       tripData trip;
//       for(size_t i=0;i<trips.size();i++){
//           if(hmap2.search(trips[i],trip,Hash)){
//               if(startS.count(stoi(trip.from))>0 && endS.count(stoi(trip.to))>0)
//               tripC++;
//           }
//       }
//       cout<<"trip count: "<<tripC<<endl;
//       }
//      else{
//          cout<<" no such trip"<<endl;
//      }
//     }
    else{
        if(hmap1.search(command,sd,Hash)){
            cout<<"Station:"<<endl;
            cout<<" ID: "<<sd.id<<endl;
            cout<<" Abbrev: "<<command<<endl;
            cout<<" Fullname: "<<sd.fullname<<endl;
            cout<<" Location: ("<<sd.latitude<<", "<<sd.longitude<<")"<<endl;
            cout<<" Capacity: "<<sd.cap<<endl;
            cout<<" Online date: "<<sd.onlineDate<<endl;
           }
        else{
            cout<<"Station not found"<<endl;
        }
    }
    cout << endl;
    cout << "Please enter a command, help, or #> ";
	getline(cin,command);
    getline(s,fCommand,' ');
    }
    
	//
	// done!
	// 
	
	return 0;
}
