/*hashmap.h*/

//
// Michael J Adami III
// U. of Illinois, Chicago
// CS 251: Spring 2020
// Project #06: hashing
//
// References: original non-collision code written by Prof. Hummel (UIC)
// Edited to implement collision by Michael Adami
// hashmap implements a hash table;
// the class is designed to handle collisions.  The class provides
// the underlying hash table along with insert() and search() functions and now with copy and = operator;
// the user of this class must provided a Hash(key, N) function that 
// hashes the given key and returns an integer in the range 0..N-1, 
// inclusive, if the key is valid.
//
// The hash function is provided in the calls to insert and search.
// Pass the name of your hash function as the 3rd parameter.  Example:
//
//   int myHash(string key, int N)
//   { ... }
//
//   int N = 10000;
//   hashmap<string, double>  hmap(N);  
//
//   if (hmap.insert("deep-dish pizza", 19.99, myHash))
//     cout << "inserted" << endl;
//   else
//     cout << "not inserted?!" << endl;
// 

#pragma once

#include <iostream>
#include <functional>

using namespace std;

template<typename KeyT, typename ValueT>
class hashmap
{
private:
  struct HashEntry
  {
    bool   ContainsData;  // false => empty, true => contains data
    KeyT   Key;           // (key, value)
    ValueT Value;
    HashEntry()
    {
      ContainsData = false;
    }
  };

  HashEntry* HT;  // hash table array of structs
  int        N;   // capacity of hash table (# of locations or array size)
  
public:
  //
  // constructor: N is the size of the underlying hash table
  //
  hashmap(int N)
  {
    this->N = N;
    this->HT = new HashEntry[N];
  }
  
  //
  // destructor
  //
  virtual ~hashmap()
  {
    delete[] this->HT;
  }

  //
  // getN
  //
  // Returns the capacity of the hash table, i.e. the value N that
  // was passed to the constructor.
  //
  int getN() const
  {
    return this->N;
  }

  //
  // insert
  //
  // Inserts the given (key, value) pair into the hash table, overwriting
  // the previous value if already inserted.  If the insert was successful
  // then true is returned, otherwise false is returned (meaning the key
  // was not hashed successfully, e.g. due to improper formatting).
  //
  // NOTE: the caller must provide a function Hash(key, N) that returns
  // an integer in the the range 0..N-1, inclusive, if the key is valid.
  // If the key is invalid, the hash function must return a negative
  // integer. The hash function is provided by simply calling insert
  // with the name of your hash function.  Example:
  //
  //   int myHash(string key, int N)
  //   { ... }
  //
  //   int N = 10000;
  //   hashmap<string, double>  hmap(N);  
  //
  //   if (hmap.insert("deep-dish pizza", 19.99, myHash))
  //     cout << "inserted" << endl;
  //   else
  //     cout << "not inserted?!" << endl;
  //
  bool insert(KeyT key, ValueT value, function<int(KeyT,int)> Hash)
  {
    //
    // Call the provided hash function with the key, and N, the size
    // of our hash table:
    //  
    //
    // insert:
    //
   int index=Hash(key,N);  
   if(index<0||index>=N)
      return false;
   while(HT[index].ContainsData){
      if(HT[index].Key==key)
          break;
      index++;
      if(index==N)
         index=0;
   }
   HT[index].Key=key;
   HT[index].Value=value;
   HT[index].ContainsData=true;
   return true;
  }

  //
  // search
  //
  // Searches the hash table for the matching key, and if found then
  // (1) the value is returned via the reference parameter and (2) true
  // is returned.  If the key could not be found, or if the hash 
  // function returned an invalid value (e.g. due to an improperly 
  // formatted key), then false is returned.
  //
  // NOTE: the caller must provide a function Hash(key, N) that returns
  // an integer in the the range 0..N-1, inclusive, if the key is valid.
  // If the key is invalid, the hash function must return a negative
  // integer. The hash function is provided by simply calling search
  // with the name of your hash function.  Example:
  //
  //   int myHash(string key, int N)
  //   { ... }
  //
  //   int N = 10000;
  //   hashmap<string, double>  hmap(N);
  //   ...
  //   double price;
  //   if (hmap.search("deep-dish pizza", price, myHash))
  //     cout << "deep-dish piazza costs " << price << endl;
  //   else
  //     cout << "not found?!" << endl;
  //
  bool search(KeyT key, ValueT& value, function<int(KeyT,int)> Hash) const
  {    
    //
    // Call the provided hash function with the key, and N, the size
    // of our hash table:
    //
    //
    // search:
    //
    int index=Hash(key,N);      
    if(index<0||index>=N)
      return false;
    while(HT[index].ContainsData){
      if(HT[index].Key==key){
         value=HT[index].Value;
         return true;
         }
      else{
         index++;
         if(index==N)
            index=0;
          } 
       }
      return false;
  }
  
  // 
  // copy constructor:
  //
  hashmap(const hashmap& other){
    N = other.getN(); //Same size
    HT = new HashEntry[N]; //make a new array
    for (int i = 0; i < N; i++) {
        this->HT[i] = other.HT[i]; // Every index should be the same
    }
  }
  
  //
  //operator=
  //
  
  hashmap& operator=(const hashmap& other){
     if (this == &other) { //Once it reaches 
        return (*this); //Return this
        }

    delete[] HT; //Delete the entired array
    this->N = other.getN(); //Copy the size
    HT = new HashEntry[N]; //Make new array
    for (int i = 0; i < N; i++){
        HT[i] = other.HT[i]; //Every index gets replaced.
    }
  }
  vector<KeyT> getKeys()
  {
    vector<KeyT> keys;
    for(int i=0;i<N;i++){
    if(HT[i].ContainsData)
        keys.push_back(HT[i].Key);
    }
    return keys;
  }

};
