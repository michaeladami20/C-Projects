/*hash.h*/

//
// Prof. Joe Hummel
// U. of Illinois, Chicago
// CS 251: Spring 2020
// 
// Project 6 Part 1: Hashing with collisions
// 

#include <string>

using namespace std;

bool isNumeric(string s);
int Hash(string theDate, int N);
