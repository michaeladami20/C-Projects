
/*test.cpp*/


//

// An AVL unit test based on Catch framework

//


#include <iostream>

#include <vector>

#include <algorithm>


#include "avlt.h"


#include "catch.hpp"


using namespace std;



TEST_CASE("(1) empty tree")

{

  avlt<int, int>  tree;


  REQUIRE(tree.size() == 0);

  REQUIRE(tree.height() == -1);

}



TEST_CASE("(2) case 1 at the root")

{

  avlt<int, int>  tree;


  vector<int> keys = { 100, 80, 60 };

  vector<int> heights = { 0, 1, 0 };


  for (int key : keys)

  {

    tree.insert(key, -key);

  }


  //

  // size and height?  after rebalance should be 1:

  //

  REQUIRE(tree.size() == keys.size());


  auto maxH = std::max_element(heights.begin(), heights.end());

  REQUIRE(tree.height() == *maxH);

  // 

  // values inserted?

  //

  int value;


  for (int key : keys)

  {

    REQUIRE(tree.search(key, value));

    REQUIRE(value == -key);

  }


  //

  // heights correct after rebalance?

  //

  for (size_t i = 0; i < keys.size(); ++i)

  {

    REQUIRE((tree % keys[i]) == heights[i]);

  }

}

TEST_CASE("(3) case 6 keys")

{

  avlt<int, int>  tree;


  vector<int> keys = { 20,45,60,21,47,73};

  vector<int> heights = {1,2,1,0,0,0};


  for (int key : keys)

  {

    tree.insert(key, -key);

  }


  //

  // size and height?  after rebalance should be 3:

  //

  REQUIRE(tree.size() == keys.size());


  auto maxH = std::max_element(heights.begin(), heights.end());

  REQUIRE(tree.height() == *maxH);

  // 

  // values inserted?

  //

  int value;


  for (int key : keys)

  {

    REQUIRE(tree.search(key, value));

    REQUIRE(value == -key);

  }


  //

  // heights correct after rebalance?

  //

  for (size_t i = 0; i < keys.size(); ++i)

  {

    REQUIRE((tree % keys[i]) == heights[i]);

  }

}

TEST_CASE("(4) case 6 keys")

{

  avlt<int, int>  tree;


  vector<int> keys = { 45,13,55,99,77,30,46};

  vector<int> heights = {3,1,1,0,2,0,0};


  for (int key : keys)

  {

    tree.insert(key, -key);

  }


  //

  // size and height?  after rebalance should be 3:

  //

  REQUIRE(tree.size() == keys.size());


  auto maxH = std::max_element(heights.begin(), heights.end());

  REQUIRE(tree.height() == *maxH);

  // 

  // values inserted?

  //

  int value;


  for (int key : keys)

  {

    REQUIRE(tree.search(key, value));

    REQUIRE(value == -key);

  }


  //

  // heights correct after rebalance?

  //

  for (size_t i = 0; i < keys.size(); ++i)

  {

    REQUIRE((tree % keys[i]) == heights[i]);

  }

}

TEST_CASE("(5) case 5 keys")

{

  avlt<int, int>  tree;


  vector<int> keys = { 98,76,91,24,13};

  vector<int> heights = {0,0,2,1,0};


  for (int key : keys)

  {

    tree.insert(key, -key);

  }


  //

  // size and height?  after rebalance should be 3:

  //

  REQUIRE(tree.size() == keys.size());


  auto maxH = std::max_element(heights.begin(), heights.end());

  REQUIRE(tree.height() == *maxH);

  // 

  // values inserted?

  //

  int value;


  for (int key : keys)

  {

    REQUIRE(tree.search(key, value));

    REQUIRE(value == -key);

  }


  //

  // heights correct after rebalance?

  //

  for (size_t i = 0; i < keys.size(); ++i)

  {

    REQUIRE((tree % keys[i]) == heights[i]);

  }

}

TEST_CASE("(6) case 7 keys")

{

  avlt<int, int>  tree;


  vector<int> keys = { 7,6,5,4,3,2,1};

  vector<int> heights = {0,1,0,2,0,1,0};


  for (int key : keys)

  {

    tree.insert(key, -key);

  }


  //

  // size and height?  after rebalance should be 3:

  //

  REQUIRE(tree.size() == keys.size());


  auto maxH = std::max_element(heights.begin(), heights.end());

  REQUIRE(tree.height() == *maxH);

  // 

  // values inserted?

  //

  int value;


  for (int key : keys)

  {

    REQUIRE(tree.search(key, value));

    REQUIRE(value == -key);

  }


  //

  // heights correct after rebalance?

  //

  for (size_t i = 0; i < keys.size(); ++i)

  {

    REQUIRE((tree % keys[i]) == heights[i]);

  }

}

TEST_CASE("(7) case 7 keys")

{

  avlt<int, int>  tree;


  vector<int> keys = { 19,17,21,24,26,27,28};

  vector<int> heights = {1,0,0,2,0,1,0};


  for (int key : keys)

  {

    tree.insert(key, -key);

  }


  //

  // size and height?  after rebalance should be 3:

  //

  REQUIRE(tree.size() == keys.size());


  auto maxH = std::max_element(heights.begin(), heights.end());

  REQUIRE(tree.height() == *maxH);

  // 

  // values inserted?

  //

  int value;


  for (int key : keys)

  {

    REQUIRE(tree.search(key, value));

    REQUIRE(value == -key);

  }


  //

  // heights correct after rebalance?

  //

  for (size_t i = 0; i < keys.size(); ++i)

  {

    REQUIRE((tree % keys[i]) == heights[i]);

  }

}

TEST_CASE("(8) case both sides have too many keys")

{

  avlt<int, int>  tree;


  vector<int> keys = { 50,48,53,64,40,32,36,34,21,80,79,77};

  vector<int> heights = {3,0,0,2,1,1,0,2,0,0,1,0};


  for (int key : keys)

  {

    tree.insert(key, -key);

  }


  //

  // size and height?  after rebalance should be 3:

  //

  REQUIRE(tree.size() == keys.size());


  auto maxH = std::max_element(heights.begin(), heights.end());

  REQUIRE(tree.height() == *maxH);

  // 

  // values inserted?

  //

  int value;


  for (int key : keys)

  {

    REQUIRE(tree.search(key, value));

    REQUIRE(value == -key);

  }


  //

  // heights correct after rebalance?

  //

  for (size_t i = 0; i < keys.size(); ++i)

  {

    REQUIRE((tree % keys[i]) == heights[i]);

  }

}