#include <iostream>

#include "avlt.h"

#include "catch.hpp"
#include<fstream>
using namespace std;


int main()
{
  ofstream i;
  i.open("Hello.txt");
  avlt<int, int>  tree;
  avlt<int,int> tree1;
  tree.insert(30,12);
  tree.insert(15,320);
  tree.insert(60,61);
  tree.insert(50,12);
  tree.insert(25,20);
  tree.insert(8,12);
  tree.insert(20,14);
  tree.insert(28,63);
  tree.insert(70,55);
//   tree.insert(50,13);
//   tree.insert(10,2);
//   tree.insert(25,20);
//   tree.insert(10,32);
//   tree.insert(13,1);
//   tree.insert(14,2);
//   tree.insert(32,2);
 tree=tree1;
 cout<<tree[120]<<endl;
//   
//   tree1.insert(90,44); 
//   tree1.insert(30,20);
//   tree1.insert(15,32);
//   tree1.insert(50,300);
//   tree1.insert(8,90);
//   tree1.insert(25,12);
//   tree1.insert(28,65);
//   tree1.insert(20,45);
//   tree1.insert(70,20);
//   tree1.insert(60,32);
  //tree=tree1;
  tree.dump(i);
  tree1.dump(i);
  return 0;
}