/*test.cpp*/

//
// An AVL unit test based on Catch framework. 
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <random>


#include "avlt.h"

#include "catch.hpp"

using namespace std;


TEST_CASE("(4.1) big tree -- 1..N, balanced?")
{
  avlt<int, int>  tree;

  //
  // insert in order, which will trigger lots of rotations:
  //
  for (int i = 1; i < 4096; ++i)
  {
    tree.insert(100, 20);
    tree.insert(40,30);
    tree.insert(30,20);

  REQUIRE(tree.size() == 4095);
  REQUIRE(tree.height() == 11);  // N = 4096, lgN - 1

  //
  // check the values, stored properly?
  //
  for (int i = 1; i < 4096; ++i)
  {
    int value;

    REQUIRE(tree.search(i, value));
    REQUIRE(value == -i);
    REQUIRE(tree[i] == -i);
  }
  
  REQUIRE((tree % 4094) == 1);
  REQUIRE(tree(4094) == 4095);

  REQUIRE((tree % 4095) == 0);
  REQUIRE(tree(4095) == 0);

  //
  // walk the tree and make sure values in order, i.e. it was
  // rotated properly:
  //
  int key;
  int i = 1;

  tree.begin();
  while (tree.next(key))
  {
    REQUIRE(key == i);
    ++i;
  }

  REQUIRE(i == (tree.size() + 1));

  REQUIRE(tree[0] == 0);
  REQUIRE(tree(0) == 0);
  REQUIRE((tree % 0) == -1);

  REQUIRE(tree[4096] == 0);
  REQUIRE(tree(4096) == 0);
  REQUIRE((tree % 4096) == -1);
}