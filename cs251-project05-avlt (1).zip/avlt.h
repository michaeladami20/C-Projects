
// 

// Michael J Adami III

// U. of Illinois, Chicago

// CS 251: Spring 2020

// Project #05:AVL tree

//

// Threaded binary search tree: An AVL tree is a data structure that self-balances through
// insertion If the heights are a difference of two it will preform a self-balance and rethread.
//

//
// Threaded AVL tree
//

#pragma once

#include <iostream>
#include <vector>
#include <stack>    
using namespace std;

template<typename KeyT, typename ValueT>
class avlt
{
private:
  struct NODE
  {
    KeyT   Key; //The key for nodes
    ValueT Value; //The value  of nodes
    NODE*  Left; //Left side
    NODE*  Right; //Right side
    bool   isThreaded; // true => Right is a thread, false => non-threaded
    int    Height;     // height of tree rooted at this node
  };

  NODE* Root;  // pointer to root node of tree (nullptr if empty)
  int   Size;  // # of nodes in the tree (0 if empty)
  NODE* NextNODE;
  /*All the way to the left. HUMMEL's CODE Use:Insert*/ 
    NODE* _getActualLeft(NODE* cur) const
  {
    return cur->Left;
  }
  /*Recurse to the actual Right. HUMMEL's CODE Use:Insert*/
  NODE* _getActualRight(NODE* cur) const
  {
    if (cur->isThreaded)  // then actual Right ptr is null:
      return nullptr;
    else  // actual Right is contents of Right ptr:
      return cur->Right;
  }
  
   /*Range of all nodes us ing the lowest and the upper key*/
  void _search(NODE* cur, KeyT lower, KeyT upper, vector<KeyT>& keys){
      if(cur == nullptr)
          return;
          //Check bottom
    if ( lower < cur->Key )  
        _search(cur->Left, lower, upper,keys);  
      
    //push it in
    if ( lower <= cur->Key && upper >= cur->Key)  
        keys.push_back(cur->Key);  
        // Check the top
    if ( upper > cur->Key )  
        _search(cur->Right, lower, upper,keys);  
   }
  /*Deletion of the tree*/
  void _postorder(NODE* cur){ 
     if(cur == nullptr)
        return;
     else{
          _postorder(cur->Left);
          if(!cur->isThreaded)
            _postorder(cur->Right);
        delete cur;
        Size--;
      }
    } 
    /* Rotate the right side*/
  void _RightRotate(NODE* Parent, NODE* N)
  {
      NODE* L=N->Left; // Root
      NODE* A=L->Left; // subtrees-LeftNODE
      NODE* B=L->Right; // subtrees-RightNODE
      NODE* C=N->Right; //subtrees-RightNODE
      /*Check for threads*/
      if(L->isThreaded==true)
          B=nullptr;
      if(N->isThreaded==true)
         C=nullptr;
      L->Right=N;
      N->Left=B;
      L->isThreaded=false;
      /*Top Node*/
      if(Parent==nullptr)
          Root=L;
      else if(Parent->Left==N)
          Parent->Left=L;
      else
          Parent->Right=L;
      //UPDATE HEIGHTS
      int HA,HB,HC;
      if(A==nullptr)
          HA=-1;
      else
         HA=A->Height;
      if(B==nullptr)
          HB=-1;
      else
         HB=B->Height;
      if(C==nullptr)
          HC=-1;
      else
          HC=C->Height;
      N->Height=1+max(HB,HC);
      L->Height=1+max(N->Height,HA);
    }
      
  /*Rotate Left side*/
  void _LeftRotate(NODE* Parent, NODE* N)
  {
      NODE* R=N->Right; //Root
      NODE* A=R->Right; //Left node
      NODE* B=R->Left; //right node
      NODE* C=N->Left; //Left node
     if(R->isThreaded==true)
        A=nullptr;
      R->Left=N;
      N->Right=B;
      if(B==NULL){
         N->isThreaded=true;
         N->Right=R;
         }
      else
          N->isThreaded=false;
      if(Parent==nullptr) // If the parent is empty
          Root=R;
      else if(Parent->Right==N) //If the parent is to the right of the child set it to right side
          Parent->Right=R;
      else // If it was to the left set it to the left
         Parent->Left=R;
      /*UPDATE THE HEIGHTS*/
      int HA,HB,HC;
      if(A==nullptr)
          HA=-1;
      else
          HA=A->Height;
      if(B==nullptr)
          HB=-1;
      else
         HB=B->Height;
      if(C==nullptr)
         HC=-1;
      else
         HC=C->Height;
      N->Height=1+max(HB,HC);
      R->Height=1+max(N->Height,HA);
  }

  /*This function copies the whole function of the copy constructor*/
  void _copy(NODE* copyRoot){
      if(copyRoot==nullptr){ // If nothing is on the tree return nothing
         return;
      }
      else{ //Not Empty
          
          insertCC(copyRoot->Key,copyRoot->Value); //Insert in tree
          _copy(copyRoot->Left); //Recursion 
          if(!copyRoot->isThreaded)
              _copy(copyRoot->Right); //Recursion
          }
      }

  void insertCC(KeyT key, ValueT value){
    NODE* prev = nullptr;
    NODE* cur = Root;
    stack <NODE*> nodes;
    // 1. Search to see if tree already contains key:
    //
    while (cur != nullptr)
    {
      if (key == cur->Key)  // already in tree
        return;
      nodes.push(cur);
      if (key < cur->Key){  // search left:
        prev=cur;
        cur = cur->Left;
      }
      else{
          if(cur->isThreaded){
              prev=cur;
              cur=nullptr;
            }
          else{
             cur = cur->Right;
          }     
      }
    }
    NODE* newNode=new NODE(); //Initialize new node
    newNode->Key= key;//Initialize key
    newNode->Value=value;//Initialize value
    newNode->Left=nullptr; // Set its left to NULL
    newNode->Right=nullptr; //Set left side to NULL
      if(cur==nullptr && prev==nullptr){
          Root=newNode;
          newNode->Right= nullptr;
          Root->Height=0;
          Root->isThreaded=true;
          }
      else{
         if(key<prev->Key){
             prev->Left=newNode; //Set the Left side the node
             newNode->Right=prev; //The right side the parent node
             newNode->isThreaded=true; //The right side to know its empty
         }
         else{
             newNode->Right=prev->Right; //Make the right node equal to the prev right node
             prev->Right=newNode; //change it to the new node
             prev->isThreaded = false; //Make sure it knows it has a child
             newNode->isThreaded=true; // No child
             }
             
        }
       Size++;
       
    while (!nodes.empty())
    {
      cur=nodes.top();
      nodes.pop();
      int hR,hL,hCur;
      
      hL = (cur->Left == nullptr) ? -1 : cur->Left->Height; // Ternary if cur->Left is empty -1 else change height
      hR = (cur->Right == nullptr) ? -1 : cur->Right->Height; //Ternary if cur->Right is empty -1 else change height
      hCur = 1 + std::max(hL, hR);
      if(cur->Height == hCur)  // didn't change, so no need to go further:
        break;
      else if(abs(hR - hL) <2)  // height changed, update and keep going:
        cur->Height = hCur;
     }
        return;
   }
   //Used for the () function
  NODE* _search2(KeyT key) const
  {
      NODE* cur = Root;
      while(cur!=nullptr){ // Keep going while there is something there.
         if (key == cur->Key && cur->Right!=nullptr){  // already in tree
            return cur;
         }         
         else if (key < cur->Key){ // search left:
            cur = cur->Left; //Keep going to the lowest
         }
         else{  //If the right is threaded just return nothing
             if(cur->isThreaded) 
              cur=nullptr;
             else //Nothing there exit
                cur=cur->Right;
            }
         }
    return nullptr;
  }
    /*Output the entire tree*/
  void _dump(NODE* cur,ostream &output)const{
      if(cur==nullptr)
         return;
      else{
         _dump(cur->Left,output);
          if(!cur->isThreaded || cur->Right==nullptr) //If not threaded keep going
              output<<"(" <<cur->Key << ","<<cur->Value <<","<< cur->Height<< ")"<<endl;  
          else // Threaded 
              output<<"("<<cur->Key<<","<<cur->Value<<","<<cur->Height<<","<<cur->Right->Key<<")"<<endl;   
           }
         if(!cur->isThreaded)
             _dump(cur->Right,output); //Right side
      }
public:
  //
  // default constructor:
  //
  // Creates an empty tree.
  //
  avlt()
  {
    Root = nullptr;
    Size = 0;
  }

  //
  // copy constructor
  //
  // NOTE: makes an exact copy of the "other" tree, such that making the
  // copy requires no rotations.
  //
  avlt (const avlt& other)
  {
    Size=0;
    Root=nullptr;
    _copy(other.Root);
  }

	//
  // destructor:
  //
  // Called automatically by system when tree is about to be destroyed;
  // this is our last chance to free any resources / memory used by
  // this tree.
  //
  virtual ~avlt()
  {
    _postorder(Root);
  }

  //
  // operator=
  //
  // Clears "this" tree and then makes a copy of the "other" tree.
  //
  // NOTE: makes an exact copy of the "other" tree, such that making the
  // copy requires no rotations.
  //
  avlt& operator=(const avlt& other)
  {
    if(this!=&other){
      _postorder(Root);
      _copy(other.Root);
      }
      return* this;
  }

  //
  // clear:
  //
  // Clears the contents of the tree, resetting the tree to empty.
  //
  void clear()
  {
    _postorder(Root);
    Size=0;
    Root=nullptr;
  }

  // 
  // size:
  //
  // Returns the # of nodes in the tree, 0 if empty.
  //
  // Time complexity:  O(1) 
  //
  int size() const
  {
    return Size;
  }

  // 
  // height:
  //
  // Returns the height of the tree, -1 if empty.
  //
  // Time complexity:  O(1) 
  //
  int height() const
  {
    if (Root == nullptr)
      return -1; //If null make empty
    else
      return Root->Height; //Change the height 
  }

  // 
  // search:
  //
  // Searches the tree for the given key, returning true if found
  // and false if not.  If the key is found, the corresponding value
  // is returned via the reference parameter.
  //
  // Time complexity:  O(lgN) worst-case
  //
  bool search(KeyT key, ValueT& value) const
  {
  NODE* cur = Root;
  while(cur!=nullptr){
     if (key == cur->Key){  // already in tree
        value=cur->Value;
        return true;
         }
         else if (key < cur->Key){  // search left:
            cur = cur->Left;
         }
         else{  //search right:
            if(cur->isThreaded){
               cur=nullptr;
            }
            else{
            cur = cur->Right;
            }
         }
      }
    return false;
    }

  //
  // range_search
  //
  // Searches the tree for all keys in the range [lower..upper], inclusive.
  // It is assumed that lower <= upper.  The keys are returned in a vector;
  // if no keys are found, then the returned vector is empty.
  //
  // Time complexity: O(lgN + M), where M is the # of keys in the range
  // [lower..upper], inclusive.
  //
  // NOTE: do not simply traverse the entire tree and select the keys
  // that fall within the range.  That would be O(N), and thus invalid.
  // Be smarter, you have the technology.
  //
  vector<KeyT> range_search(KeyT lower, KeyT upper)
  {
    vector<KeyT>  keys;
    _search(Root,lower,upper,keys);
    return keys;
  }

  //
  // insert
  //
  // Inserts the given key into the tree; if the key has already been insert then
  // the function returns without changing the tree.  Rotations are performed
  // as necessary to keep the tree balanced according to AVL definition.
  //
  // Time complexity:  O(lgN) worst-case
  //
  void insert(KeyT key, ValueT value)
  {
    NODE* prev = nullptr;
    NODE* cur = Root;
    //
    // stack the nodes we visit so we can walk back up
    // the search path later, adjusting heights:
    //    
    stack<NODE*> nodes;
    //
    // 1. Search to see if tree already contains key:
    //
     while (cur != nullptr)
    {
      if (key == cur->Key)  // already in tree
        return;
      nodes.push(cur);  // stack so we can return later:

      if (key < cur->Key)  // search left:
      {
        prev = cur;
        cur = _getActualLeft(cur);
      }
      else
      {
        prev = cur;
        cur = _getActualRight(cur);
      }
    }//while
    
    //
    // 2. if we get here, key is not in tree, so allocate
    // a new node to insert:
    // 
    
    NODE* newNode = new NODE();
    newNode->Key = key;
    newNode->Value = value;
    newNode->Height=0;
    newNode->Left = nullptr;
    newNode->Right=nullptr;
    //
    // 3. link in the new node:
    //
    // NOTE: cur is null, and prev denotes node where
    // we fell out of the tree.  if prev is null, then
    // the tree is empty and the Root pointer needs 
    // to be updated.
    //

   if(cur == nullptr && prev==nullptr){
      Root=newNode; //Make the node = the top
      newNode->isThreaded= true;
      newNode->Right=nullptr;
   }
   else{
     if(key<prev->Key){
         prev->Left=newNode; //Set the Left side the node
         newNode->isThreaded=true; //The right side to know its empty
         newNode->Right=prev; //The right side the parent node
     }
     else{
         newNode->isThreaded=true; // No child
         newNode->Right=prev->Right; //Make the right node equal to the prev right node
         prev->isThreaded = false; //Make sure it knows it has a child
         prev->Right=newNode; //change it to the new node
         }    
    }
    Size++;
 
    //
    // 5. walk back up tree using stack and update heights.
    //
    while (!nodes.empty())
    {
      cur=nodes.top();
      nodes.pop();
      NODE* parent;
      int hR,hL,hCur;
      hL = (cur->Left == nullptr) ? -1 : cur->Left->Height; // Ternary if cur->Left is empty -1 else change height
      if(!cur->isThreaded){
          hR = cur->Right->Height; //Ternary if cur->Right is empty -1 else change height
          hCur = 1 + std::max(hL, hR);
      }
      else
          hR=-1;
          hCur=1+std::max(hL,hR);
      int balance = hL-hR; 
      /*Get Heights*/
      if(cur->Height == hCur)  // didn't change, so no need to go further:
        break;
      else if(abs(hL - hR)< 2)  // height changed, update and keep going:
        cur->Height = hCur;
      else{ //UNBALANCED
          if(nodes.empty())
              parent=nullptr;
          else
              parent=nodes.top();
            //Right Right Case
          if (balance > 1 && key < cur->Left->Key){
             _RightRotate(parent,cur);
             continue;
          }
            // Left Left Case  
          if (balance < -1 && key > cur->Right->Key){
             _LeftRotate(parent,cur);
             continue;
          }
            // Left Right Case  
            if (balance > 1 && key > cur->Left->Key)  
            {  
                _LeftRotate(cur,cur->Left);
                _RightRotate(parent,cur);
                continue;
            }  

            // Right Left Case  
            if (balance < -1 && key < cur->Right->Key)  
            {  
                _RightRotate(cur,cur->Right); 
                _LeftRotate(parent,cur);
                continue;
            }  
          }
        }   
        //while
        //
        // done!
        //
        return;
      }

  //
  // []
  //
  // Returns the value for the given key; if the key is not found,
  // the default value ValueT{} is returned.
  //
  // Time complexity:  O(lgN) worst-case
  //
  ValueT operator[](KeyT key) const
  {
    ValueT value;
    if(search(key,value)){
        return value; //The next key
    }
    return ValueT{}; //Default
  }

  //
  // ()
  //
  // Finds the key in the tree, and returns the key to the "right".
  // If the right is threaded, this will be the next inorder key.
  // if the right is not threaded, it will be the key of whatever
  // node is immediately to the right.
  //
  // If no such key exists, or there is no key to the "right", the
  // default key value KeyT{} is returned.
  //
  // Time complexity:  O(lgN) worst-case
  //
  KeyT operator()(KeyT key) const
  {
      NODE* cur = Root;
      while(cur!=nullptr){ // Keep going while there is something there.
         if (key == cur->Key && cur->Right!=nullptr){  // already in tree
            return cur->Right->Key;
         }         
         else if (key < cur->Key){ // search left:
            cur = cur->Left; //Keep going to the lowest
         }
         else{  //If the right is threaded just return nothing
             if(cur->isThreaded) 
              cur=nullptr;
             else //Nothing there exit
                cur=cur->Right;
            }
         }
     return KeyT{};
  }

  //
  // %
  //
  // Returns the height stored in the node that contains key; if key is
  // not found, -1 is returned.
  //
  // Example:  cout << tree%12345 << endl;
  //
  // Time complexity:  O(lgN) worst-case
  //
  int operator%(KeyT key) const
  {
    NODE* cur = Root;
    while(cur!=nullptr){
     if (key == cur->Key){  // already in tree
        return cur->Height;
         }
         else if (key < cur->Key){  // search left:
            cur = cur->Left;
         }
         else{  //search right:
            if(cur->isThreaded){
               cur=nullptr;
            }
            else{
            cur = cur->Right;
            }
         }
      }
    return -1;//Not found in tree
  }

  //
  // begin
  //
  // Resets internal state for an inorder traversal.  After the 
  // call to begin(), the internal state denotes the first inorder
  // key; this ensure that first call to next() function returns
  // the first inorder key.
  //
  // Space complexity: O(1)
  // Time complexity:  O(lgN) worst-case
  //
  // Example usage:
  //    tree.begin();
  //    while (tree.next(key))
  //      cout << key << endl;
  //
  void begin()
  {
      NextNODE=Root;
      if(NextNODE==nullptr)
          return;
      while(NextNODE->Left != nullptr)
            NextNODE=NextNODE->Left; 
  }

  //
  // next
  //
  // Uses the internal state to return the next inorder key, and 
  // then advances the internal state in anticipation of future
  // calls.  If a key is in fact returned (via the reference 
  // parameter), true is also returned.
  //
  // False is returned when the internal state has reached null,
  // meaning no more keys are available.  This is the end of the
  // inorder traversal.
  //
  // Space complexity: O(1)
  // Time complexity:  O(lgN) worst-case
  //
  // Example usage:
  //    tree.begin();
  //    while (tree.next(key))
  //      cout << key << endl;
  //
  bool next(KeyT& key)
  {
      if(NextNODE==nullptr){
          key=KeyT{};
          return false;
          }

      if (!NextNODE->isThreaded){ //If you can't go right make go right once.
          key=NextNODE->Key; //Remake the key= the other key
          NextNODE = NextNODE->Right; //Move Right
          while(NextNODE->Left!=nullptr)
              NextNODE=NextNODE->Left;
          return true;
       }
      else{ //If you can go right(Right then down)
          key=NextNODE->Key; //Key = the current node key
          NextNODE=NextNODE->Right; // Move Right
          return true; // Return Found
      }
  }

  //
  // dump
  // 
  // Dumps the contents of the tree to the output stream, using a
  // recursive inorder traversal.
  //
  void dump(ostream& output) const
  {
    output << "**************************************************" << endl;
    output << "********************* AVLT ***********************" << endl;
    output << "** size: " << this->size() << endl;
    output << "** height: " << this->height() << endl;
    //
    // inorder traversal, with one output per line: either 
    // (key,value,height) or (key,value,height,THREAD)
    //
    // (key,value,height) if the node is not threaded OR thread==nullptr
    // (key,value,height,THREAD) if the node is threaded and THREAD denotes the next inorder key
    //
    _dump(Root,output);
    output << "**************************************************" << endl;
  }
	
};

